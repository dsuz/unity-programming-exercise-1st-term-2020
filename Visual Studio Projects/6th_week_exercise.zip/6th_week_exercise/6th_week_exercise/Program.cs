﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _6th_week_exercise
{
    class Program
    {
        static void Main(string[] args)
        {
            Exercise07();   // やさしい
            //Exercise08();
            //Exercise09();
            //Exercise10(); // やややさしい
            //Exercise11();
            //Exercise12(); // ふつう
            //Exercise13();
            //Exercise14();
            //Exercise15();
            //Exercise16();
            //Exercise17(); // ややむずかしい
            //Exercise18();
            Console.ReadLine(); // Enter を押すまで抜けないために書いている
        }

        /// <summary>
        /// int 型の変数 x に任意の数値を代入し、x を 2 倍、3 倍、4 倍した結果を出力せよ。
        /// </summary>
        static void Exercise07()
        {
            int x = 12344564;
            Console.Write(x);
        }

        /// <summary>
        /// int 型の変数 x に任意の数値を代入し、x を 1 乗、2 乗、3 乗した結果を出力せよ。
        /// </summary>
        static void Exercise08()
        {
            int x = 12344564;
            Console.Write(x);
        }

        /// <summary>
        /// int 型の変数 x に任意の数値を代入し、x を x より小さい任意の数値で割った商と余りを出力せよ。
        /// </summary>
        static void Exercise09()
        {
            int x = 12344564;
            Console.Write(x);
        }

        /// <summary>
        /// int 型の変数 x、y にそれぞれ数値を入力し、x が y より大きい場合に、"xはyより大きい" と出力せよ
        /// </summary>
        static void Exercise10()
        {
            // ヒント: x, y に数値を入力させる
            int x, y;
            Console.WriteLine("整数 x を入力してください");
            string buf = Console.ReadLine();
            x = int.Parse(buf);
            Console.WriteLine("整数 y を入力してください");
            buf = Console.ReadLine();
            y = int.Parse(buf);
            Console.Write("x: {0}, y: {1}", x, y);
        }

        /// <summary>
        /// int 型の変数 x、y にそれぞれ数値を入力し、
        /// x が y より大きい場合には "xはyより大きい"、
        /// x が y より小さい場合には "xはyより小さい"、
        /// x と y が等しい場合には "xとyは等しい" と出力せよ。
        /// </summary>
        static void Exercise11()
        {
        }

        /// <summary>
        /// 課題12. 3つの数値を標準入力から受け取り、その平均値を出力せよ。
        /// </summary>
        static void Exercise12()
        {
            // ヒント: 入力を３回受け付ける
            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine("{0} つめの数値を入力してください", i + 1);
                string buf = Console.ReadLine();
                float f = float.Parse(buf);
                Console.WriteLine("{0} が入力されました", f);
            }
        }

        /// <summary>
        /// 課題13. 標準入力から数値を3回受け取り、それらの最大値を出力せよ。
        /// </summary>
        static void Exercise13()
        {
        }

        /// <summary>
        /// 課題14. 標準入力から自然数を受け取り、その数だけ "*" を出力せよ。
        /// </summary>
        static void Exercise14()
        {
        }


        /// <summary>
        /// 課題15. 標準入力から数値を5回受け取り、それらの最大値と最小値を出力せよ。
        /// </summary>
        static void Exercise15()
        {
        }

        /// <summary>
        /// 課題16. 数値をくり返し入力させ、入力された数値の合計が 100 を超えたら入力を止めて合計を出力せよ。
        /// </summary>
        static void Exercise16()
        {
        }

        /// <summary>
        /// 課題17. 数値をくり返し入力させ、入力された数値の合計が 100 を超えたら入力を止め、これまで入力された数値を全て出力せよ。
        /// </summary>
        static void Exercise17()
        {
        }

        /// <summary>
        /// 課題18. 九九の表を出力せよ。
        /// </summary>
        static void Exercise18()
        {
            // ヒント: ２次元配列の変数 kuku を初期化し、要素の値を出力する
            int[,] kuku = new int[9, 9];

            for (int i = 0; i < 9; i++)
            {
                for (int j = 0; j < 9; j++)
                {
                    Console.Write("{0,2}", kuku[i, j]); // 整形して出力する
                }
                Console.WriteLine();
            }
        }
    }
}
